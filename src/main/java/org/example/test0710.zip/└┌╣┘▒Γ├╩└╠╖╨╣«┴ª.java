package org.example.test0710;

public class 자바기초이론문제 {
}

/*
Q1 - D

Q2 - D

Q3 - D

Q4- D

Q5- B

Q6- D

Q7- C

Q8- B

Q9- D

Q10- B

Q11-1

Q12- 이름 정의된게 없어서

 */