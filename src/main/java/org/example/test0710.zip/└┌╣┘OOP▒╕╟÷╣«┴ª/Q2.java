package org.example.test0710.자바OOP구현문제;

class Parson {
    private String name;
    private int age;

    private getter{
        this.name = name;
        this.age = age;
    }

    private setter{

    }
}



public class Q2 {
    public static void main(String[] args) {

    }
}
