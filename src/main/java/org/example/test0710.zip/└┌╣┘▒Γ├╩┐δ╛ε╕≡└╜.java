package org.example.test0710;

public class 자바기초용어모음 {
}
/*
접근제한자

public : 클래스/패키지 접근 허용
protected : 패키지 내에서 접근 허용, 상속의 하위 자식 메소드만 가능
default : 패키지 내에서 접근 허용
private : 한 클래스 내에서만 접근 허용



static

static 변수 : 정적 변수 - 모든 인스턴스에서 공유가능한 변수
static 메서드 : 정적 메서드 - 객체 생성 후 호출 가능한 메서드



final

final 변수 : 상수로 변하지 않음
final 메서드 : 변하지 않는 메서드
final 클래스 : 변하지 않는 클래스



super VS this

this : 메서드 정의
super : 상속에서 상위 메서드를 들고오기 위한



오버로딩 VS 오버라이딩

오버로딩 : 클래스 내에서 동일한 메서드 여러게 사용
오버라이딩 : 상속관계에서 메서드 재정의

abstract

abstract 클래스 : 추상화. 불완전한 클래스
abstract 메서드 :



interface VS abstract class

interface :
abstract class : 추상화. 불완전한 클래스



extends VS implement

extends : 상속관계의 상위 클래스를 하위 클래스로 데이터와 메서드를 연결

implements :



try-catch-finally

try : 잘못된 출력을 잡을 수 있게 시도
catch : 잘못된 출력을 잡아 옳게 출력
finally :
 */