package org.example.test0717.프로그래밍언어활용.book_management_system.exception;

public class BookNotFoundException {
}
