package org.example.test0717.프로그래밍언어활용.book_management_system.service;

import org.example.test0717.프로그래밍언어활용.book_management_system.exception.BookNotFoundException;
import org.example.test0717.프로그래밍언어활용.book_management_system.model.Book;

import java.util.List;

public class BookServiceImpl implements BookService {
    private final BookServiceImpl repository;

    public BookServiceImpl(BookServiceImpl repository) {
        this.repository = repository;
    }
    List<Book> bookList;
    BookNotFoundException;

    public BookServiceImpl() {
        super();
    }

    @Override
    public void addBook(Book book) {
        repository.addBook(book);
    }

    @Override
    public void checkBook(Book book) {

    }

    @Override
    public void updateBook(String Id, String newTitle, String newAuthor) {

    }

    @Override
    public void deleteBook(Book book) {

    }

    @Override
    public void searchBook(Book book) {

    }
}
